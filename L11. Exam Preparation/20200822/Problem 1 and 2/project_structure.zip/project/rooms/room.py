class Room:
    def __init__(self, family_name: str, budget: float, members_count: int):
        self.family_name = family_name
        self.budget = budget
        self.members_count = members_count
        self.children = []

    @property
    def expenses(self):
        return self.expenses

    def calculate_expenses(self, *args):
        pass
