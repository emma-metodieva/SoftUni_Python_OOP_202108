from project.medicine.medicine import Medicine
from project.medicine.painkiller import Painkiller
from project.medicine.salve import Salve
from project.supply.food_supply import FoodSupply
from project.supply.supply import Supply
from project.supply.water_supply import WaterSupply
from project.survivor import Survivor


class Bunker:
    def __init__(self):
        self.survivors = []
        self.supplies = []
        self.medicine = []

    @property
    def food(self):
        food_list = [s for s in self.supplies if isinstance(s, FoodSupply)]
        if len(food_list) == 0:
            raise IndexError("There are no food supplies left!")
        return food_list

    @property
    def water(self):
        water_list = [w for w in self.supplies if isinstance(w, WaterSupply)]
        if len(water_list) == 0:
            raise IndexError("There are no water supplies left!")
        return water_list

    @property
    def painkillers(self):
        painkiller_list = [p for p in self.medicine if isinstance(p, Painkiller)]
        if len(painkiller_list) == 0:
            raise IndexError("There are no painkillers left!")
        return painkiller_list

    @property
    def salves(self):
        salves_list = [s for s in self.medicine if isinstance(s, Salve)]
        if len(salves_list) == 0:
            raise IndexError("There are no salves left!")
        return salves_list

    def add_survivor(self, survivor: Survivor):
        pass

    def add_supply(self, supply: Supply):
        pass

    def add_medicine(self, medicine: Medicine):
        pass

    def heal(self, survivor: Survivor, medicine_type: str):
        pass

    def sustain(self, survivor: Survivor, sustenance_type: str):
        pass

    def next_day(self):
        pass
