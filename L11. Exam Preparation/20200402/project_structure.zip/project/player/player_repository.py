class PlayerRepository:
    def __init__(self):
        self.count = 0
        self.players = []

    def add(self, player):
        pass
        # add_player_username = player.username
        # player_usernames = [player.username for player in self.players]
        # if add_player_username in player_usernames:
        #     raise ValueError(f"Player {add_player_username} already exists!")
        # self.players.append(player)
        # self.count += 1

    def remove(self, player):
        pass
        # if player == '':
        #     raise ValueError("Player cannot be an empty string!")
        # for player in self.players:
        #     if player.username == player:
        #         self.players.remove(player)
        #         self.count -= 1

    def find(self, username):
        pass
        # for player in self.players:
        #     if player.username == username:
        #         return player
