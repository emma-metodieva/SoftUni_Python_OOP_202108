# from project.player.beginner import Beginner


class BattleField:
    @staticmethod
    def fight(attacker, enemy):
        pass

        # players = [attacker, enemy]
        #
        # for player in players:
        #     if player.is_dead:
        #         raise ValueError("Player is dead!")
        #
        #     if isinstance(player, Beginner):
        #         player.health += 40
        #         for card in player.card_repository.cards:
        #             card.damage_points += 30
        #
        #     bonus_health_points = 0
        #     for card in player.card_repository.cards:
        #         bonus_health_points += card.health_points
        #
        # cycle = 0
        # while True:
        #     for player in players:
        #         if not 0 <= cycle < len(player.card_repository.cards):
        #             break
        #
        #         damage = player.card_repository.cards[cycle].damage_points
        #         if player == attacker:
        #             enemy.health -= damage
        #             if enemy.is_dead:
        #                 break
        #         else:
        #             attacker.health -= damage
        #             if attacker.is_dead:
        #                 break
        #
        #     cycle += 1
