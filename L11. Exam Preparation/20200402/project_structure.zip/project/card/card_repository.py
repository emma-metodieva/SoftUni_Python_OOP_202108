class CardRepository:
    def __init__(self):
        self.count = 0
        self.cards = []

    def add(self, card):
        pass
        # add_card_name = card.name
        # card_names = [card.name for card in self.cards]
        # if add_card_name in card_names:
        #     raise ValueError(f"Card {add_card_name} already exists!")
        # self.cards.append(card)
        # self.count += 1

    def remove(self, card):
        pass
        # if card == '':
        #     raise ValueError("Card cannot be an empty string!")
        # for card in self.cards:
        #     if card.username == card:
        #         self.cards.remove(card)
        #         self.count -= 1

    def find(self, name):
        pass
        # for card in self.cards:
        #     if card.name == name:
        #         return card
